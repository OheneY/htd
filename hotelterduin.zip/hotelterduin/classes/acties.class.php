<?php 

class acties extends DB{
  public function getPost() {
    $sql = "SELECT * FROM klant";
    $stmt = $this->__construct()->prepare($sql);
    $stmt->execute();

    while($result = $stmt->fetchAll()) {
      return $result;
    };
  }

  public function add($naam, $adres, $plaats, $postcode, $telefoon) {

    $sql = "INSERT INTO klant(naam, adres, plaats, postcode, telefoon) VALUES (?, ?, ?, ?, ?)";
    $stmt = $this->__construct()->prepare($sql);
    $stmt->execute([$naam, $adres, $plaats, $postcode, $telefoon]);
  }

  public function edit($id) {
    $sql = "SELECT * FROM klant WHERE id = ?";
    $stmt = $this->__construct()->prepare($sql);
    $stmt->execute([$id]);
    $result = $stmt->fetch();

    return $result;
  }

  public function update($id, $title, $body, $author) {
    $sql = "UPDATE klant SET naam = ?, adres = ?, postcode = ?, postcode = ?, telefoon = ? WHERE id = ?";
    $stmt = $this->__construct()->prepare($sql);
    $stmt->execute([$title, $body, $author, $id]);
  }

  public function del($id) {
    $sql = "DELETE FROM klant WHERE id = ?";
    $stmt = $this->__construct()->prepare($sql);
    $stmt->execute([$id]);
  }
}