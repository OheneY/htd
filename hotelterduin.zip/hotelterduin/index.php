<?php  

    include "class_autoload_inc.php";
    $db = new DB();


?>

<?=sjabloon_header('Home') ?>

        <?php  $acties = new acties() ; ?>
        <?php  if($acties->getPost()) : ?>
        
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">klantnummer</th>
                    <th scope="col">naam</th>
                    <th scope="col">adres</th>
                    <th scope="col">plaats</th>
                    <th scope="col">postcode</th>
                    <th scope="col">telefoon</th>
                    </tr>
            </thead>
            <?php  foreach($acties->getPost() as $actie) : ?>
            <tbody>
                
                <tr>
                    <td><?= $actie['klantnummer']; ?></td>
                    <td><?= $actie['naam']; ?></td>
                    <td><?= $actie['adres']; ?></td>
                    <td><?= $actie['plaats']; ?></td>
                    <td><?= $actie['postcode']; ?></td>
                    <td><?= $actie['telefoon']; ?></td>
                </tr>
            </tbody>
            <?php  endforeach ; ?>
        </table>
       
        <?php  endif ; ?>
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
        Launch static backdrop modal
        </button>

        <!-- Modal -->
        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Modal title</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form action="klant.process.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label">Naam</label>
                        <input type="text" name="naam" class="form-control" >
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Adres</label>
                        <input type="text" name="adres" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Plaats</label>
                        <input type="text" name="plaats" class="form-control" >
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Postcode</label>
                        <input type="text" name="pc" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Telefoon</label>
                        <input type="text" name="tel" class="form-control" >
                    </div>
                    <button type="submit" class="btn btn-primary" name="submit">Submit</button>
            </form><br />
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Sluiten</button>
            </div>
            </div>
        </div>
        </div>
    
<?=sjabloon_footer() ?>

