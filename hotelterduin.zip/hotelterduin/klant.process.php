<?php  
    
    include "class_autoload_inc.php";
    $acties = new acties() ;

    if(isset($_POST['submit'])) {
        $naam = $_POST['naam'];
        $adres = $_POST['adres'];
        $plaats = $_POST['plaats'];
        $postcode = $_POST['pc'];
        $telefoon = $_POST['tel'];
      
        $acties->add($naam, $adres, $plaats, $postcode, $telefoon);
        
      
        header("location: index.php");
    }

?>