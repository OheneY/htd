<?php  

    include "class_autoload_inc.php"; 

    $db = new DB();


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        
    $stmt = "INSERT INTO klant (klantnummer, naam, adres, plaats, postcode, telefoon) VALUES( :klantnummer, :naam, :adres, :plaats, :postcode, :telefoon)";

    $placeholders = [
        'klantnummer'=>NULL,
        'naam'=>$_POST['naam'],
        'adres'=>$_POST['adres'],
        'plaats'=>$_POST['plaats'],
        'postcode'=>$_POST['postcode'],
        'telefoon'=>$_POST['telefoon']
    ];

    $db->operation($stmt, $placeholders);


}

?>
<?=sjabloon_header('Klanten') ?>
<form method="POST">
    <div class="mb-3">
        <label class="form-label">Naam</label>
        <input type="text" name="naam" class="form-control" >
    </div>
    <div class="mb-3">
        <label class="form-label">Adres</label>
        <input type="text" name="adres" class="form-control">
    </div>
    <div class="mb-3">
        <label class="form-label">Plaats</label>
        <input type="text" name="plaats" class="form-control" >
    </div>
    <div class="mb-3">
        <label class="form-label">Postcode</label>
        <input type="text" name="pc" class="form-control">
    </div>
    <div class="mb-3">
        <label class="form-label">Telefoon</label>
        <input type="text" name="tel" class="form-control" >
    </div>
    <!--
    <div class="mb-3">
        <label class="form-label">Van</label>
        <input type="date" name="van" class="form-control" >
    </div>
    <div class="mb-3">
        <label class="form-label">Tot</label>
        <input type="date" name="tot" class="form-control">
    </div>
    -->
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?=sjabloon_footer() ?>

